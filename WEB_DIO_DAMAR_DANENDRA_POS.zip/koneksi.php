<?php 
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "ujikom_pos";

    $koneksi = mysqli_connect($hostname, $username, $password, $database);
?>