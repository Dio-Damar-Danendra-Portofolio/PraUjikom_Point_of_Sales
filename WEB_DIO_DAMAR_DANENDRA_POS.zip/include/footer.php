<footer>
        <div class="container-fluid">
            <div class="row p-2 d-flex flex-wrap justify-content-center align-self-center">
                <div class="col-lg-8 text-center bg-warning w-100 align-items-center fixed-bottom">
                    <h4>&copy; <?php echo date('Y'); ?> Resto PPKD Jakarta Pusat</h4>
                </div>
            </div>
        </div>
    </footer>